<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
	<title>Premicom</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>resources/css/main.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>resources/css/adminpage.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>resources/css/src.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>resources/css/read.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>resources/css/marketplace.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url() ?>resources/css/dropzone.css">
	<link href="<?php echo base_url(); ?>resources/css/marketplace2.css" rel="stylesheet>">
</head>
