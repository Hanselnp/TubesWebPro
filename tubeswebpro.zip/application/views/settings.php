<?php include ('header.php'); ?>
  <body>
    <?php include ('navbar.php'); ?>
    <div class="wrapper">
      <?php include ('sidebar.php'); ?>
    </div>
    <?php include ('javascript-loader.php'); ?>
  </body>
</html>
<?php include('footer.php'); ?>
