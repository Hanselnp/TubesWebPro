<?php include ('header.php'); ?>
  <body>
    <?php include ('admin_navbar.php'); ?>
    <div class="wrapper">
      <?php include ('sidebar.php'); ?>
      <div class="col-12 col-sm-10">
        <div class="container" style="padding-bottom: 30px;">
          <div class="row">

          </div>
        </div>
      </div>
    </div>
    <?php include ('javascript-loader.php'); ?>
  </body>
</html>
<?php include('footer.php'); ?>
