# TubesWebPro

## Nama Proyek
Premicom (Premium Comic)

## Apa itu Premicom?
Premicom adalah sebuah platform untuk menghimpun komik digital dari uploader untuk kemudian dijual yang keuntungannya kembali ke pembuat komik.

## Target Penyelesaian
12 Maret 2018

## Version
1