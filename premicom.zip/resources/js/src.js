var src_input = getElementsByClassName('search-button').value;

function test_bla(var a){
  return a;
}
