<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chapters extends CI_Controller {
	public function index()
	{
		$this->load->view('comic-chapter');
	}
}
