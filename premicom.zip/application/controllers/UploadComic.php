<?php
  defined('BASEPATH') OR exit('No direct script access allowed');

  class UploadComic extends CI_Controller {
    public function uploadCover() {
      // $imageName = time().".".$request->{$request->transferName}->getClientOriginalExtension();
      // $transferName= $request->transferName;
      // $request->{$transferName}->move(public_path()."/uploads/".$uploadDir, $imageName);
      //
      // if (!File::exists(public_path().'/uploads/'.$uploadDir."/".$imageName)) {
      //   clearstatcache();
      //   return response()->json([
      //     "Error" => 2,
      //     "image" => [
      //       'imageName' => $imageName,
      //       'imageUrl' => $imageName,
      //       'uploadDir' => $uploadDir
      //     ]
      //   ]);
      // } else {
      //   clearstatcache();
      //   return response()->json([
      //     "Error" => 0,
      //     "image" => [
      //       'imageName' => $imageName,
      //       'imageUrl' => $imageName,
      //       'uploadDir' => $uploadDir
      //     ]
      //   ]);
      // }
    }

    public function uploadPages() {
      $this->load->model('Comics_model');
      echo var_dump($this->input->post('transferName'));
      $files = $this->input->post('transferName');
      echo $this->Comics_model->uploadPages($files);
      // $linkJson = [];
      // $uploadDir = "comics/comic";
      // $files = $request->file($request->transferName);
      // $no_of_files = count($files);
      // if ($no_of_files == 0) {
      //   return response()->json([
      //     "Error" => 1
      //   ]);
      // } else {
      //   for ($i = 0; $i<$no_of_files; $i++) {
      //     $file = $files[$i];
      //     if ($file) {
      //       $imageName = time().str_replace(array('\n', ' ', '\%20'), '', $file->getClientOriginalName());
      //       $transferName= $file;
      //       $file->move(public_path().'/uploads/'.$uploadDir, $imageName);
      //       array_push($linkJson, $imageName);
      //       // if (File::exists(public_path().'/uploads/'.$uploadDir."/".$imageName)) {
      //       //   clearstatcache();
      //       // }
      //     } else {
      //       return response()->json([
      //         "Error" => 998
      //       ]);
      //     }
      //   }
      // }
      // return response()->json([
      //   "Error" => 0,
      //   "Page" => [
      //     "Url" => $linkJson,
      //   ]
      // ]);
    }
  }
?>
