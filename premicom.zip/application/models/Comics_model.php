<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Comics_model extends CI_Model {
  public function getTitle($id) {
    return 0;
  }

  public function getId($id) {
    return 0;
  }

  public function getAllComics() {
    return 0;
  }

  public function uploadCover($inputName) {
    $coverDir = "uploads/comics/covers/";
    return $this->doUpload($inputName, $coverDir);
  }

  public function uploadPages($inputName) {
    $pagesDir = "uploads/comics/pages/";
    return $this->doUpload($inputName, $pagesDir);
  }

  public function doUpload($inputName, $uploadDir) {
    if (!empty($_FILES)) {
      $tempFile = $_FILES[$inputName]['tmp_name'];
      $fileName = $_FILES[$inputName]['name'];
      $fileName = str_replace(' ', '_', $fileName);
      $targetPath = APPPATH.$uploadDir;
      $targetFile = $targetPath . $fileName ;
      move_uploaded_file($tempFile, $targetFile);
      return $fileName;
      // if you want to save in db,where here
      // with out model just for example
      // $this->load->database(); // load database
      // $this->db->insert('file_table',array('file_name' => $fileName));
     }
  }
}
