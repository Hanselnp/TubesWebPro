<div style="width: 100%;">
  <nav class="mCustomScrollbar _mCS_1 mCS-autohide" id="sidebar" style="overflow: visible;">
    <div class="sidebar-inner-container">
      <div class="sidebar-header">
      <h4>Dummy123</h4><!-- put your images profile here -->
      <img src="<?php echo base_url(); ?>resources/images/samplephoto.jpg"></div>
      <ul class="remove-dot list unstyled components">
        <li class="active">
          <a href="<?php echo base_url(); ?>adminpage"><span><i class="fas fa-home"></i></span> Beranda</a>
        </li>
        <li>
          <a href="<?php echo base_url(); ?>adminpage/comics"><span><i class="fas fa-book"></i></span> Komik</a>
        </li>
        <li>
          <a href="<?php echo base_url(); ?>adminpage/stats"><span><i class="fas fa-chart-bar"></i></span> Statistik</a>
        </li>
        <li>
          <a href="#"><span><i class="fas fa-edit"></i></span> Update Profil</a>
        </li>
        <li>
          <a href="#"><span><i class="fas fa-cog"></i></span> Pengaturan</a>
        </li>
      </ul>
    </div>
  </nav>
</div>
